#!/bin/sh
echo -ne '\033c\033]0;Your First 2D Game With Godot 4- START (GDQuest)\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/TutotialGame2.x86_64" "$@"
